class Main3{
    public static void main(String args[]){
        String s = "Java is so much of fun";
        for (int i =1;i<=5;i++){
            System.out.println(s);
        }
    }
}
class Main5{
    public static void main(String args[]){

        System.out.println("This is the second day of the java Trainig class");
    }
}
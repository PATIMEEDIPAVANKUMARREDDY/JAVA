class Main2{
    public static void main(String args[]){
        int n = 7;
        for (int i=1;i <= n;i++){
            System.out.println(n + "*" + i + "=" + n*i);
        }
    }
}
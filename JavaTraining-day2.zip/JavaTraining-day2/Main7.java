// Assignment operators 

class Main7{
    public static void main(String args[]){
        int j = 33;
        int var;
        var = j;
        System.out.println("var using = : "+var);
        var += j;
        System.out.println("var using += : "+var);
        var *= j;
        System.out.println("var using *= : "+var);
        var -= j;
        System.out.println ("var using -+ : " +var);
    }
}
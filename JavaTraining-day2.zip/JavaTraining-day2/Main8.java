// comparison operators
class Main8{
    public static void main(String args[]){
        int a = 435;
        int b = 3;
        System.out.println(a==b);
        System.out.println(a>b);
        System.out.println(a<b);
        System.out.println(a!=b);
    }
}